import time

from src.char.BaseChar import SwitchPriority
from src.char.Lucilla import Lucilla as NativeLucilla


class Lucilla(NativeLucilla):
    """沿用内置攒能量和变身重击，按实况确认大招与切人。"""

    SWITCH_IN_SETTLE = 0.30
    CHARGE_TIME_OUT = 6.0
    CAST_CONFIRM_CAP = 1.40
    CAST_RETRY_INTERVAL = 0.22

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if (has_intro and current_char is not None and current_char.name == 'Suisui'
                and self.task.use_liberation
                and self.task.get_cd('liberation', self.index) <= self.LIBERATION_CD_SKIP):
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def try_liberation(self):
        if not self.task.use_liberation or not self.liberation_available():
            return False
        if self.echo_available():
            self.click_echo(time_out=0)
            self.task.next_frame()
        # 尝试过就结束本次站场，避免还没确认前在攒能量循环里重按。
        self.perform_liberation()
        self.switch_next_char()
        return True

    def perform_liberation(self):
        deadline = time.monotonic() + self.CAST_CONFIRM_CAP
        next_press = 0.0
        attempts = 0
        hidden_frames = 0
        while time.monotonic() < deadline:
            self.task.next_frame()
            visible, current, _ = self.task.in_team()
            if not visible and attempts:
                hidden_frames += 1
                if hidden_frames == 2:
                    self.record_liberation_use()
                    self.logger.info('hls adaptive: 洛瑟菈解放已确认出手')
                    self.sleep(self.LIBERATION_ANIMATION_TIME, check_combat=False)
                    self.pulse_heavy_attack(self.LIBERATION_HEAVY_TIME)
                    return True
            elif visible:
                hidden_frames = 0
                if current != self.index:
                    return False
                if time.monotonic() >= next_press and self.liberation_available():
                    self.send_liberation_key(down_time=0.04)
                    attempts += 1
                    next_press = time.monotonic() + self.CAST_RETRY_INTERVAL
            self.sleep(0.05, check_combat=False)
        self.logger.info('hls adaptive: 洛瑟菈解放未确认，切人继续轮转')
        return False
