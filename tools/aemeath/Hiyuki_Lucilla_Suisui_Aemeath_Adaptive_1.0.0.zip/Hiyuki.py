import time

from src.char.Hiyuki import Hiyuki as NativeHiyuki


class Hiyuki(NativeHiyuki):
    """沿用内置见心、居合判定和切人，仅缩短未出手的归刃等待。"""

    R2_HOLD_CAP = 2.45
    R2_RELEASE_CAP = 1.25
    R2_HUD_RETURN_CAP = 7.0

    def hold_liberation(self):
        if not self.task.use_liberation or time.monotonic() < getattr(self, '_r2_retry_at', 0.0):
            return False
        self.task.next_frame()
        visible, current, _ = self.task.in_team()
        if not visible or current != self.index or not self.liberation_available():
            return False

        key = self.get_liberation_key()
        hidden_frames = 0
        hidden_since = None
        previous_liberation = self.task.in_liberation
        held = False
        self.task.in_liberation = True
        try:
            self.task.send_key_down(key)
            held = True
            hold_until = time.monotonic() + self.R2_HOLD_CAP
            deadline = None
            while hidden_frames < 2:
                now = time.monotonic()
                if held and now >= hold_until:
                    self.task.send_key_up(key)
                    held = False
                    # 游戏可能在松键后才开始归刃演出。
                    deadline = time.monotonic() + self.R2_RELEASE_CAP
                if deadline is not None and now >= deadline:
                    self._r2_retry_at = now + 1.0
                    self.logger.info('hls adaptive: 归刃未确认，恢复内置战斗判断')
                    return False
                self.sleep(0.05, check_combat=False)
                self.task.next_frame()
                visible, current, _ = self.task.in_team()
                if visible:
                    if current != self.index:
                        return False
                    hidden_frames = 0
                    hidden_since = None
                else:
                    if hidden_since is None:
                        hidden_since = time.time()
                    hidden_frames += 1

            if held:
                self.task.send_key_up(key)
                held = False
            self.record_liberation_use()
            returned = self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.R2_HUD_RETURN_CAP)
            self.add_freeze_duration(hidden_since, time.time() - hidden_since)
            if not returned:
                self.task.raise_not_in_combat('hls adaptive: 归刃出手后队伍栏恢复超时')
            self.logger.info('hls adaptive: 归刃已确认出手')
            return True
        finally:
            try:
                if held:
                    self.task.send_key_up(key)
            finally:
                self.task.in_liberation = previous_liberation
